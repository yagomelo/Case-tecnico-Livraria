﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Data
{
    public class ProgressoLivrariaDbContext : DbContext
    {
        public ProgressoLivrariaDbContext (DbContextOptions<ProgressoLivrariaDbContext> options)
            : base(options)
        {
        }

        public DbSet<ProgressoLivraria.Models.Livro> Livro { get; set; } = default!;
        public DbSet<ProgressoLivraria.Models.Cliente> Cliente { get; set; } = default!;
        public DbSet<ProgressoLivraria.Models.Venda> Venda { get; set; } = default!;
    }
}
