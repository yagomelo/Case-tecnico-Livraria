using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ILogger<IndexModel> _logger;

        private ProgressoLivrariaDbContext _dbContext;

        public IList<Livro> Livros;

        [BindProperty]
        public Venda Venda { get; set; } = default!;

        public IndexModel(ILogger<IndexModel> logger, ProgressoLivrariaDbContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }

        public async Task OnGetAsync()
        {
            Livros = await _dbContext.Livro.ToListAsync<Livro>();
        }

        public async Task<IActionResult> OnPostComprarAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }
            else
            {
                var livro = await _dbContext.Livro.FirstOrDefaultAsync(m => m.ISBN == id.ToString());
                
                if(livro != null)
                {
                    Venda = new Venda
                    {
                        NomeLivro = livro.Titulo,
                        QtdVendida = 1,
                        DtVenda = DateTime.UtcNow
                    };

                    _dbContext.Venda.Add(Venda);
                    await _dbContext.SaveChangesAsync();

                    livro.QtdEstoque = livro.QtdEstoque - 1;

                    _dbContext.Livro.Update(livro);
                    await _dbContext.SaveChangesAsync();
                }
            }

            return RedirectToPage("./Index");
        }
    }
}
