using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProgressoLivraria.Pages.Shared.DisplayTemplates
{
    public class _CustomCPFModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
