using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ProgressoLivraria.Pages.Shared
{
    public class _CustomConfirmModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
