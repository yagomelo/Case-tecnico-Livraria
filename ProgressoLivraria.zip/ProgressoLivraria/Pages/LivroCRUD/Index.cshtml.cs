﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.LivroCRUD
{
    public class IndexModel : PageModel
    {
        private readonly ProgressoLivraria.Data.ProgressoLivrariaDbContext _context;

        public IndexModel(ProgressoLivraria.Data.ProgressoLivrariaDbContext context)
        {
            _context = context;
        }

        public IList<Livro> Livro { get;set; } = default!;

        public async Task OnGetAsync()
        {
            Livro = await _context.Livro.ToListAsync();
        }
    }
}
