﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.LivroCRUD
{
    public class DeleteModel : PageModel
    {
        private readonly ProgressoLivraria.Data.ProgressoLivrariaDbContext _context;

        public DeleteModel(ProgressoLivraria.Data.ProgressoLivrariaDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public Livro Livro { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var livro = await _context.Livro.FirstOrDefaultAsync(m => m.ISBN == id);

            if (livro == null)
            {
                return NotFound();
            }
            else
            {
                Livro = livro;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(string id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var livro = await _context.Livro.FindAsync(id);
            if (livro != null)
            {
                Livro = livro;
                _context.Livro.Remove(Livro);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
