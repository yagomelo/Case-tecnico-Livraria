using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.ClienteCRUD
{
    public class IncluirModel : PageModel
    {
        private ProgressoLivrariaDbContext _dbContext;

        [BindProperty]
        public Cliente Cliente { get; set; } = default!;

        public IncluirModel(ProgressoLivrariaDbContext context)
        {
            _dbContext = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        public async Task<IActionResult> OnPostAsync()
        {
            var cliente = new Cliente();

            if (await TryUpdateModelAsync<Cliente>(cliente, "cliente", 
                obj => obj.Nome, obj => obj.DtNascimento, obj => obj.CPF ))
            {
                _dbContext.Cliente.Add(cliente);
                await _dbContext.SaveChangesAsync();
                return RedirectToPage("./Listar");
            }

            return Page();
        }
    }
}
