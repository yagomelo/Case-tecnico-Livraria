using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.ClienteCRUD
{
    public class ExcluirModel : PageModel
    {
        private readonly ProgressoLivrariaDbContext _dbContext;

        public ExcluirModel(ProgressoLivrariaDbContext context)
        {
            _dbContext = context;
        }

        [BindProperty]
        public Cliente Cliente { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = await _dbContext.Cliente.FirstOrDefaultAsync(m => m.IdCliente == id);

            if (cliente == null)
            {
                return NotFound();
            }
            else
            {
                Cliente = cliente;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = await _dbContext.Cliente.FindAsync(id);
            if (cliente != null)
            {
                Cliente = cliente;
                _dbContext.Cliente.Remove(Cliente);
                await _dbContext.SaveChangesAsync();
            }

            return RedirectToPage("./Listar");
        }
    }
}
