using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using Microsoft.Identity.Client;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.ClienteCRUD
{
    public class AlterarModel : PageModel
    {
        private ProgressoLivrariaDbContext _dbContext;

        [BindProperty]
        public Cliente Cliente { get; set; } = default!;

        public AlterarModel(ProgressoLivrariaDbContext context)
        {
            _dbContext = context;
        }
        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            Cliente = await _dbContext.Cliente.FirstOrDefaultAsync(m => m.IdCliente == id);

            if (Cliente == null)
            {
                return NotFound();
            }

            return Page();            
        }

        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _dbContext.Attach(Cliente).State = EntityState.Modified;

            try
            {
                await _dbContext.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!ClienteAindaExiste(Cliente.IdCliente))
                {
                    return NotFound(0);
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Listar");
        }

        private bool ClienteAindaExiste(int id)
        {
            return _dbContext.Cliente.Any(m => m.IdCliente == id);
        }
    }
}
