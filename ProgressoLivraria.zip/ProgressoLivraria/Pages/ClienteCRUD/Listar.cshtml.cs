using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.ClienteCRUD
{
    public class ListarModel : PageModel
    {
        private readonly ProgressoLivrariaDbContext _dbContext;

        public IList<Cliente> Cliente { get; set; } = default!;

        public ListarModel(ProgressoLivrariaDbContext context)
        {
            _dbContext = context;
        }

        public async Task OnGetAsync()
        {
            Cliente = await _dbContext.Cliente.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var cliente = await _dbContext.Cliente.FindAsync(id);

            if (cliente != null)
            {
                _dbContext.Cliente.Remove(cliente);
                await _dbContext.SaveChangesAsync();
            }

            return RedirectToPage("./Listar");
        }
    }
}
