using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages.Relatorio
{
    public class IndexModel : PageModel
    {
        private readonly ProgressoLivraria.Data.ProgressoLivrariaDbContext _context;

        public IndexModel(ProgressoLivraria.Data.ProgressoLivrariaDbContext context)
        {
            _context = context;
        }

        public IList<Venda> Venda { get; set; } = default!;
        public async Task OnGetAsync()
        {
            Venda = await _context.Venda.ToListAsync();
        }
    }
}
