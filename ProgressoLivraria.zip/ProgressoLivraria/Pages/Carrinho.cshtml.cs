using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using ProgressoLivraria.Data;
using ProgressoLivraria.Models;

namespace ProgressoLivraria.Pages
{
    public class CarrinhoModel : PageModel
    {
        private ProgressoLivrariaDbContext _dbContext;

        private const string COOKIE_NAME = ".AspNetCore.CartId";

        public Venda Venda { get; set; }
        public Livro Livro { get; set; }
        public double TotalPedido { get; set; }

        public CarrinhoModel(ProgressoLivrariaDbContext context )
        {
            _dbContext = context;
        }

        //public async Task<IActionResult> OnGetAsync()
        //{
        //    if (Request.Cookies.ContainsKey(COOKIE_NAME))
        //    {
        //        var cartId = Request.Cookies[COOKIE_NAME];
        //        Livro = await _dbContext.Livro.Include("Livro").FirstOrDefaultAsync(p => p.ISBN == cartId);
        //        if (Livro == null)
        //        {
        //            TotalPedido = Livro.
        //        }
        //    }
        //}
    }
}
