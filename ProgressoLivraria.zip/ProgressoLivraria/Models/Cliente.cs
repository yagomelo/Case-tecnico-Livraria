﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;


namespace ProgressoLivraria.Models
{
    public class Cliente
    {
        [Key]
        public int IdCliente { get; set; }

        [Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [MaxLength(100)]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [Display(Name = "Data de Nascimento")]
        [DataType(DataType.Date, ErrorMessage ="O campo {0} deve conter uma data válida.")]
        public DateTime DtNascimento { get; set; }

        [Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [MaxLength(11)]
        [RegularExpression(@"[0-9]{11}$", ErrorMessage ="O campo {0} deve ser preenchido com 11 dígitos numéricos.")]
        [UIHint("_CustomCPF")]
        public string CPF { get; set; }
    }
}
