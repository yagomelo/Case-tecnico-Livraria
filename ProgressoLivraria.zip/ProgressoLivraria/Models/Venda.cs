﻿using System.ComponentModel.DataAnnotations;

namespace ProgressoLivraria.Models
{
    public class Venda
    {
        [Key]
        public int IdVenda { get; set; }

        //[Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [MaxLength(100)]
        [Display(Name = "Título")]
        public string NomeLivro { get; set; }

        //[Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [Display(Name = "Quantidade")]
        public int QtdVendida { get; set; }

        //[Required(ErrorMessage = "O campo {0} é de preenchimento obrigatório.")]
        [Display(Name = "Data da Venda")]
        [DataType(DataType.Date, ErrorMessage = "O campo {0} deve conter uma data válida.")]
        public DateTime DtVenda { get; set; }
    }
}
